Please check the video tutorial at 3 minutes and 14 seconds onwards to use our new one-click demo importer:
https://youtu.be/yPmFxjQMjcc?t=194

WP Dashboard >> Appearance >> Theme Options >> Import/Export